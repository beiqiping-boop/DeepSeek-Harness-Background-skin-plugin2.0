/* dsh-skin-sakura —— 宿主半端（0.6.0）
 *
 * 存储：$DSH_HOME/skin-sakura/config.json + images/（仅"复制"模式的图）
 *
 * 路由：
 *   GET    /api/skin-sakura/config        读配置
 *   POST   /api/skin-sakura/config        写配置 { config }
 *   GET    /api/skin-sakura/photo?slot=   按配置里的「路径」读原图（不复制）
 *   POST   /api/skin-sakura/image         存图 { dataUrl }（复制模式）
 *   GET    /api/skin-sakura/image/<name>  取图
 *   DELETE /api/skin-sakura/image/<name>  删图
 *
 * 安全：photo 只接受 slot（default / rule:<id>），路径只从配置里取，
 *       不接受任意路径参数，且只允许 jpg/jpeg/png/webp/gif。
 */
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

export const name = 'dsh-skin-sakura'
export const inject = ['webServer']

const LOG = '[dsh-skin-sakura]'
const home = () => process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const baseDir = () => path.join(home(), 'skin-sakura')
const cfgPath = () => path.join(baseDir(), 'config.json')
const imgDir = () => path.join(baseDir(), 'images')

const MIME = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
}
const NAME_RE = /^[A-Za-z0-9_-]{1,80}\.(?:jpg|jpeg|png|webp|gif)$/
const MAX_BYTES = 30 * 1024 * 1024

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true })
}

function readCfg() {
  try {
    const v = JSON.parse(fs.readFileSync(cfgPath(), 'utf8'))
    return v && typeof v === 'object' ? v : null
  } catch (e) {
    return null
  }
}

function writeCfg(cfg) {
  ensureDir(baseDir())
  fs.writeFileSync(cfgPath(), JSON.stringify(cfg, null, 2), 'utf8')
}

function safeImagePath(name) {
  if (!NAME_RE.test(name)) return null
  return path.join(imgDir(), name)
}

function fileOfSource(src) {
  if (!src || typeof src !== 'object') return null
  if (src.kind === 'copy') {
    const n = String(src.name || '')
    return NAME_RE.test(n) ? path.join(imgDir(), n) : null
  }
  if (src.kind === 'path') {
    const raw = String(src.path || '').trim()
    if (!raw) return null
    const p = path.resolve(raw)
    const ext = path.extname(p).toLowerCase()
    if (!MIME[ext]) return null
    return p
  }
  return null
}

function sourceOfSlot(cfg, slot) {
  if (!cfg) return null
  if (slot === 'default') return (cfg.default && cfg.default.source) || null
  if (slot.indexOf('rule:') === 0) {
    const id = slot.slice(5)
    const list = Array.isArray(cfg.rules) ? cfg.rules : []
    const hit = list.find((r) => r && r.id === id)
    return hit ? hit.source || null : null
  }
  return null
}

function saveDataUrl(dataUrl) {
  const m = /^data:image\/(jpeg|jpg|png|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''))
  if (!m) throw new Error('不支持的图片格式')
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1]
  const buf = Buffer.from(m[2], 'base64')
  if (buf.length < 16) throw new Error('图片内容为空')
  if (buf.length > MAX_BYTES) throw new Error('图片太大')
  ensureDir(imgDir())
  const name = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8) + '.' + ext
  fs.writeFileSync(path.join(imgDir(), name), buf)
  return name
}

function readBody(req) {
  return new Promise((resolve) => {
    let buf = ''
    req.on('data', (c) => {
      buf += c
      if (buf.length > MAX_BYTES * 1.6) req.destroy()
    })
    req.on('end', () => resolve(buf))
    req.on('error', () => resolve(''))
  })
}

export function apply(ctx) {
  try {
    if (!ctx || !ctx.webServer || typeof ctx.webServer.register !== 'function') {
      console.log(LOG + ' 没有 webServer，跳过')
      return
    }
    ensureDir(baseDir())

    ctx.effect(() => ctx.webServer.register({
      kind: 'prefix',
      path: '/api/skin-sakura',
      handler: async (req, res) => {
        const url = new URL(String(req.url || '/'), 'http://x')
        const sub = decodeURIComponent(url.pathname.replace(/^\/api\/skin-sakura/, '') || '/')
        const send = (code, obj) => {
          res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          res.end(JSON.stringify(obj))
        }

        try {
          if (sub === '/config' && (req.method === 'GET' || req.method === 'HEAD')) {
            return send(200, { ok: true, config: readCfg(), dir: baseDir() })
          }

          if (sub === '/config' && req.method === 'POST') {
            const raw = await readBody(req)
            let body = {}
            try { body = raw ? JSON.parse(raw) : {} } catch (e) { return send(400, { ok: false, error: 'JSON 解析失败' }) }
            const cfg = body && typeof body.config === 'object' && body.config !== null ? body.config : null
            if (!cfg) return send(400, { ok: false, error: '缺少 config' })
            writeCfg(cfg)
            return send(200, { ok: true, dir: baseDir() })
          }

          if (sub === '/photo') {
            const slot = String(url.searchParams.get('slot') || 'default')
            const cfg = readCfg()
            const src = sourceOfSlot(cfg, slot)
            const file = fileOfSource(src)
            if (!file) return send(404, { ok: false, error: '这个位置还没有设置图片' })
            let st
            try { st = fs.statSync(file) } catch (e) { return send(404, { ok: false, error: '读不到这张图（路径失效？）' }) }
            if (!st.isFile()) return send(404, { ok: false, error: '不是文件' })
            if (st.size > MAX_BYTES) return send(413, { ok: false, error: '图片超过 30MB' })
            const etag = '"' + st.size.toString(16) + '-' + Math.round(st.mtimeMs).toString(16) + '"'
            if (req.headers['if-none-match'] === etag) {
              res.writeHead(304, { etag, 'cache-control': 'private, max-age=60' })
              return res.end()
            }
            const ext = path.extname(file).toLowerCase()
            const buf = fs.readFileSync(file)
            res.writeHead(200, {
              'content-type': MIME[ext] || 'application/octet-stream',
              'content-length': String(buf.length),
              etag,
              'cache-control': 'private, max-age=60',
            })
            return res.end(buf)
          }

          if (sub === '/image' && req.method === 'POST') {
            const raw = await readBody(req)
            let body = {}
            try { body = raw ? JSON.parse(raw) : {} } catch (e) { return send(400, { ok: false, error: 'JSON 解析失败' }) }
            try {
              const n = saveDataUrl(body.dataUrl)
              return send(200, { ok: true, name: n, url: '/api/skin-sakura/image/' + n })
            } catch (e) {
              return send(400, { ok: false, error: e.message })
            }
          }

          if (sub.indexOf('/image/') === 0) {
            const name = sub.slice('/image/'.length)
            const file = safeImagePath(name)
            if (!file || !fs.existsSync(file)) return send(404, { ok: false, error: '没有这张图' })
            if (req.method === 'DELETE') {
              try { fs.unlinkSync(file) } catch (e) { /* ignore */ }
              return send(200, { ok: true })
            }
            const ext = path.extname(name).toLowerCase()
            const buf = fs.readFileSync(file)
            res.writeHead(200, {
              'content-type': MIME[ext] || 'application/octet-stream',
              'cache-control': 'public, max-age=31536000, immutable',
              'content-length': String(buf.length),
            })
            return res.end(buf)
          }

          return send(404, { ok: false, error: 'not found' })
        } catch (e) {
          console.error(LOG + ' 路由异常', e)
          return send(500, { ok: false, error: String(e && e.message ? e.message : e) })
        }
      },
    }), 'skin-sakura: /api/skin-sakura 路由')

    console.log(LOG + ' 已挂载 0.6.0（家=' + baseDir() + '）')
  } catch (e) {
    console.error(LOG + ' 挂载失败', e)
  }
}
