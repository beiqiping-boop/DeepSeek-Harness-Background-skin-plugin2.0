/* dsh-skin-sakura —— 浏览器端 bundle（0.6.0）
 *
 * 两种模式：
 *   single —— 一张背景，没有时段；
 *   multi  —— 默认背景 + 最多 10 条时段规则（每日 / 一次性）。
 * 每条背景（含默认）都有自己的 强度 / 模糊 / 水平 / 垂直。
 *
 * 图片来源两种：
 *   { kind: 'path', path: 'D:\\图片\\a.jpg' }  —— 直接引用原图，不复制（默认）
 *   { kind: 'copy', name: 'abc.jpg' }          —— 复制进插件目录（怕原图被移动时用）
 *
 * 配置存宿主磁盘（$DSH_HOME/skin-sakura/config.json），不依赖 localStorage。
 */
window.__ModuleLoader__.load({
  id: 'dsh-skin-sakura',
  factory: (require) => {
    const React = require('react')
    const h = React.createElement

    const KEY = 'dsh-skin-sakura:v1'
    const API = '/api/skin-sakura'
    const LIMIT = 10
    const VER = 2

    const DEFAULTS = {
      version: VER,
      mode: 'single',
      enabled: true,
      darkFollow: true,
      default: {
        source: { kind: 'path', path: '' },
        clarity: 70, blur: 1.2, posX: 50, posY: 40,
      },
      rules: [],
    }

    const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0))
    const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d)
    const pad2 = (n) => String(n).padStart(2, '0')
    const uid = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)

    /* ---------------- 时间 ---------------- */
    function hmToMin(s) {
      const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || ''))
      if (!m) return null
      const v = Number(m[1]) * 60 + Number(m[2])
      return v >= 0 && v < 1440 ? v : null
    }
    function dailyMatch(from, to, now) {
      const a = hmToMin(from)
      const b = hmToMin(to)
      if (a === null || b === null || a === b) return false
      const t = now.getHours() * 60 + now.getMinutes()
      return a < b ? (t >= a && t < b) : (t >= a || t < b)
    }
    function absMatch(from, to, now) {
      const s = Date.parse(from)
      const e = Date.parse(to)
      if (isNaN(s) || isNaN(e) || s > e) return false
      const t = now.getTime()
      return t >= s && t <= e
    }
    function ruleMatch(r, now) {
      if (!r || r.enabled === false) return false
      const w = r.when || {}
      if (w.type === 'daily') return dailyMatch(w.from, w.to, now)
      if (w.type === 'absolute') return absMatch(w.from, w.to, now)
      return false
    }
    function isExpired(r, now) {
      const w = (r && r.when) || {}
      if (w.type !== 'absolute') return false
      const e = Date.parse(w.to)
      return Number.isFinite(e) && e < now.getTime()
    }
    function activeRule(cfg, now) {
      if (cfg.mode !== 'multi') return null
      for (const r of Array.isArray(cfg.rules) ? cfg.rules : []) if (ruleMatch(r, now)) return r
      return null
    }
    function nextBoundary(cfg, now) {
      if (cfg.mode !== 'multi') return Infinity
      const t = now.getTime()
      let best = Infinity
      const push = (ts) => { if (Number.isFinite(ts) && ts > t + 500 && ts < best) best = ts }
      const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()
      for (const r of Array.isArray(cfg.rules) ? cfg.rules : []) {
        if (!r || r.enabled === false) continue
        const w = r.when || {}
        if (w.type === 'daily') {
          const a = hmToMin(w.from)
          const b = hmToMin(w.to)
          if (a === null || b === null) continue
          for (const off of [0, 1]) {
            push(day0 + off * 86400000 + a * 60000)
            push(day0 + off * 86400000 + b * 60000)
          }
        } else if (w.type === 'absolute') {
          const s = Date.parse(w.from)
          const e = Date.parse(w.to)
          if (Number.isFinite(s)) push(s)
          if (Number.isFinite(e)) push(e + 1000)
        }
      }
      return best
    }
    function fmtBoundary(ts, now) {
      if (!Number.isFinite(ts)) return ''
      const d = new Date(ts)
      const same = d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate()
      return same
        ? pad2(d.getHours()) + ':' + pad2(d.getMinutes())
        : (d.getMonth() + 1) + '-' + d.getDate() + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes())
    }

    /* ---------------- 图片地址 ---------------- */
    function sourceUrl(src, slot) {
      if (!src || typeof src !== 'object') return ''
      if (src.kind === 'copy' && src.name) return API + '/image/' + encodeURIComponent(src.name)
      if (src.kind === 'path' && src.path) return API + '/photo?slot=' + encodeURIComponent(slot)
      return ''
    }
    function hasSource(src) {
      if (!src) return false
      return (src.kind === 'copy' && !!src.name) || (src.kind === 'path' && !!src.path)
    }

    /* ---------------- 存储 ---------------- */
    const STORE = { cfg: DEFAULTS, active: null, ready: false, source: 'local', error: '' }
    const listeners = new Set()
    function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn) }
    function emit() { for (const fn of listeners) { try { fn() } catch (e) { /* noop */ } } }

    function migrate(cfg) {
      if (cfg && Number(cfg.version) === VER) return cfg
      const d = cfg || {}
      const base = {
        clarity: num(d.clarity, 70),
        blur: num(d.blur, 1.2),
        posX: num(d.posX, 50),
        posY: num(d.posY, 40),
      }
      const def = Object.assign({
        source: d.image ? { kind: 'copy', name: d.image } : { kind: 'path', path: '' },
      }, base)
      const rules = (Array.isArray(d.rules) ? d.rules : []).map((r) => Object.assign({
        id: r.id || uid(),
        name: r.name || '规则',
        enabled: r.enabled !== false,
        when: r.when || { type: 'daily', from: '22:00', to: '06:00' },
        source: r.image ? { kind: 'copy', name: r.image } : { kind: 'path', path: '' },
      }, base))
      return {
        version: VER,
        mode: rules.length ? 'multi' : (d.mode === 'multi' ? 'multi' : 'single'),
        enabled: d.enabled !== false,
        darkFollow: d.darkFollow !== false,
        default: def,
        rules,
      }
    }
    function setStore(cfg, source) {
      const m = migrate(cfg)
      m.rules = Array.isArray(m.rules) ? m.rules : []
      STORE.cfg = m
      STORE.source = source || STORE.source
      STORE.ready = true
      emit()
    }
    function localCfg() {
      try {
        const raw = localStorage.getItem(KEY)
        return raw ? JSON.parse(raw) : null
      } catch (e) { return null }
    }
    async function postJson(path, body) {
      const r = await fetch(API + path, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j || j.ok === false) throw new Error((j && j.error) || ('HTTP ' + r.status))
      return j
    }
    async function saveCfg(cfg) {
      try {
        await postJson('/config', { config: cfg })
        STORE.error = ''
        return true
      } catch (e) {
        STORE.error = '保存到磁盘失败：' + e.message
        emit()
        return false
      }
    }
    async function boot() {
      let remote = null
      try {
        const r = await fetch(API + '/config', { cache: 'no-store' })
        if (r.ok) {
          const j = await r.json()
          if (j && j.ok && j.config && typeof j.config === 'object') remote = j.config
        }
      } catch (e) { /* 宿主不可用 */ }

      if (remote) {
        setStore(remote, 'disk')
        if (Number(remote.version) !== VER) await saveCfg(STORE.cfg)
        sync(); schedule(); return
      }

      const old = localCfg()
      setStore(old, 'migrated')
      await saveCfg(STORE.cfg)
      sync(); schedule()
    }

    /* ---------------- 背景 ---------------- */
    const WHITE_ART = 'linear-gradient(#ffffff, #ffffff)'
    const artLayers = (image) => (image ? 'url("' + image + '")' : WHITE_ART)
    const rgba = (a) => 'rgba(255, 255, 255, ' + a.toFixed(3) + ')'
    const rgbaDark = (a) => 'rgba(12, 14, 18, ' + a.toFixed(3) + ')'

    function buildCss(cfg, ent, image) {
      if (!cfg.enabled) return ''
      const clarity = clamp(ent.clarity, 0, 100)
      const mid = 0.92 - 0.004 * clarity
      const top = Math.min(0.985, mid + 0.26)
      const bot = Math.min(0.985, mid + 0.12)
      const blur = clamp(ent.blur, 0, 12)
      const posX = clamp(ent.posX, 0, 100)
      const posY = clamp(ent.posY, 0, 100)
      const dark = cfg.darkFollow
        ? [
            'body[data-ds-dark-theme] div[class*="_centerCol"]::before {',
            '  background-image:',
            '    linear-gradient(180deg,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.30)) + ' 0%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.18)) + ' 18%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.14)) + ' 55%,',
            '      ' + rgbaDark(Math.min(0.99, mid + 0.22)) + ' 100%),',
            '    ' + artLayers(image) + ';',
            '}',
          ].join('\n')
        : ''
      return [
        'div[class*="_centerCol"] {',
        '  position: relative;',
        '  isolation: isolate;',
        '  background: transparent !important;',
        '}',
        'div[class*="_centerCol"]::before {',
        '  content: "";',
        '  position: absolute;',
        '  inset: 0;',
        '  z-index: -1;',
        '  pointer-events: none;',
        '  filter: blur(' + blur + 'px) saturate(1.02);',
        '  transform: scale(1.03);',
        '  background-image:',
        '    linear-gradient(180deg,',
        '      ' + rgba(top) + ' 0%,',
        '      ' + rgba(Math.max(0, mid - 0.02)) + ' 18%,',
        '      ' + rgba(mid) + ' 55%,',
        '      ' + rgba(bot) + ' 100%),',
        '    ' + artLayers(image) + ';',
        '  background-size: cover, cover;',
        '  background-position: center top, ' + posX + '% ' + posY + '%;',
        '  background-repeat: no-repeat, no-repeat;',
        '}',
        '',
        'header[class*="_header"],',
        'div[data-phase],',
        'div[class*="_scrollBody"],',
        'div[class*="_composerSeat"],',
        'div[class*="_centerCol"] [class*="hero"],',
        'div[class*="_centerCol"] [class*="Hero"] {',
        '  background: transparent !important;',
        '}',
        dark,
      ].join('\n')
    }

    let skinStyle = null
    function applySkin(cfg, ent, image) {
      if (!skinStyle) return
      try { skinStyle.textContent = buildCss(cfg, ent, image) } catch (e) { skinStyle.textContent = '' }
    }

    let tickTimer = null
    function schedule() {
      if (tickTimer) clearTimeout(tickTimer)
      const nb = nextBoundary(STORE.cfg, new Date())
      const wait = Number.isFinite(nb) ? Math.min(Math.max(nb - Date.now() + 300, 1000), 60000) : 60000
      tickTimer = setTimeout(() => { sync(); schedule() }, wait)
    }

    let lastSig = ''
    function sync() {
      const cfg = STORE.cfg
      const now = new Date()
      const rule = activeRule(cfg, now)
      const ent = rule || cfg.default
      const slot = rule ? ('rule:' + rule.id) : 'default'
      STORE.active = rule ? (rule.name || '未命名规则') : null
      const img = hasSource(ent.source) ? sourceUrl(ent.source, slot) : ''
      const sig = JSON.stringify([cfg.enabled, cfg.darkFollow, ent.clarity, ent.blur, ent.posX, ent.posY, img])
      if (sig === lastSig) return
      lastSig = sig
      applySkin(cfg, ent, img)
    }

    /* ---------------- 悬浮调参条（在设置之外，能边看工作区边调） ---------------- */
    let floatUI = null
    function currentEntry() {
      const now = new Date()
      const rule = activeRule(STORE.cfg, now)
      return { rule, ent: rule || STORE.cfg.default }
    }
    function setParam(key, v) {
      const { rule } = currentEntry()
      if (rule) {
        const rules = (STORE.cfg.rules || []).map((r) => (r.id === rule.id ? Object.assign({}, r, { [key]: v }) : r))
        STORE.cfg = Object.assign({}, STORE.cfg, { rules })
      } else {
        STORE.cfg = Object.assign({}, STORE.cfg, { default: Object.assign({}, STORE.cfg.default, { [key]: v }) })
      }
      sync()
      emit()
      saveCfg(STORE.cfg)
    }
    function buildFloat() {
      if (floatUI) return floatUI
      const box = document.createElement('div')
      box.setAttribute('data-sk-float', '')

      const head = document.createElement('div')
      head.setAttribute('data-sk-float-head', '')
      const title = document.createElement('span')
      title.setAttribute('data-sk-float-title', '')
      title.textContent = '背景调参'
      const close = document.createElement('button')
      close.setAttribute('data-sk-float-close', '')
      close.textContent = '×'
      close.onclick = () => { box.style.display = 'none' }
      head.appendChild(title)
      head.appendChild(close)
      box.appendChild(head)

      const rows = {}
      const defs = [
        ['clarity', '强度', 0, 100, 5],
        ['blur', '模糊', 0, 8, 0.4],
        ['posX', '水平', 0, 100, 1],
        ['posY', '垂直', 0, 100, 1],
      ]
      for (const def of defs) {
        const key = def[0]
        const row = document.createElement('div')
        row.setAttribute('data-sk-float-row', '')
        const lab = document.createElement('span')
        lab.setAttribute('data-sk-float-lab', '')
        lab.textContent = def[1]
        const inp = document.createElement('input')
        inp.type = 'range'
        inp.min = String(def[2]); inp.max = String(def[3]); inp.step = String(def[4])
        const val = document.createElement('span')
        val.setAttribute('data-sk-float-val', '')
        inp.oninput = function () {
          const v = Number(inp.value)
          val.textContent = key === 'blur' ? v.toFixed(1) : String(Math.round(v))
          setParam(key, v)
        }
        row.appendChild(lab); row.appendChild(inp); row.appendChild(val)
        box.appendChild(row)
        rows[key] = { inp: inp, val: val }
      }

      const foot = document.createElement('div')
      foot.setAttribute('data-sk-float-foot', '')
      foot.textContent = '改完点 ×；设置里也能调'
      box.appendChild(foot)

      document.body.appendChild(box)
      floatUI = { box: box, rows: rows, title: title }
      return floatUI
    }
    function openFloat() {
      const f = buildFloat()
      const cur = currentEntry()
      f.box.style.display = 'block'
      f.title.textContent = '背景调参 · ' + (cur.rule ? (cur.rule.name || '规则') : '默认背景')
      const defaults = { clarity: 70, blur: 1.2, posX: 50, posY: 40 }
      for (const key in f.rows) {
        const v = num(cur.ent[key], defaults[key])
        f.rows[key].inp.value = String(v)
        f.rows[key].val.textContent = key === 'blur' ? v.toFixed(1) : String(Math.round(v))
      }
    }

    /* ---------------- 样式 ---------------- */
    const CSS = [
      '[data-sk-page]{display:flex;flex-direction:column;gap:18px;padding:2px 2px 8px;max-width:700px;}',
      '[data-sk-sec]{display:flex;flex-direction:column;gap:8px;}',
      '[data-sk-h]{font-size:11px;font-weight:600;letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9aa0a6);}',
      '[data-sk-row]{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}',
      '[data-sk-grow]{flex:1;min-width:0;}',
      '[data-sk-label]{font-size:13px;}',
      '[data-sk-note]{font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary,#9aa0a6);}',
      '[data-sk-sw]{flex:none;width:38px;height:22px;border-radius:11px;border:0;cursor:pointer;position:relative;',
      '  background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.35));transition:background .15s;padding:0;}',
      '[data-sk-sw][data-on]{background:#3b82f6;}',
      '[data-sk-sw] i{position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;',
      '  transition:left .15s;display:block;}',
      '[data-sk-sw][data-on] i{left:19px;}',
      '[data-sk-range]{flex:none;width:180px;accent-color:#3b82f6;cursor:pointer;}',
      '[data-sk-val]{flex:none;width:52px;text-align:right;font-size:12px;font-variant-numeric:tabular-nums;',
      '  color:var(--dsw-alias-label-secondary,#6b7280);}',
      '[data-sk-btn]{padding:6px 12px;border-radius:8px;font-size:12px;cursor:pointer;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));',
      '  background:var(--dsw-alias-interactive-bg,rgba(128,128,128,.08));',
      '  color:var(--dsw-alias-label-primary,inherit);}',
      '[data-sk-btn]:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.16));}',
      '[data-sk-btn][data-sk-mini]{padding:3px 8px;font-size:11px;}',
      '[data-sk-btn][data-sk-on]{border-color:#3b82f6;color:#3b82f6;background:rgba(59,130,246,.10);}',
      '[data-sk-btn]:disabled{opacity:.4;cursor:not-allowed;}',
      '[data-sk-thumb]{width:150px;height:84px;border-radius:10px;object-fit:cover;display:block;flex:none;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));background:#fff;}',
      '[data-sk-thumb][data-sk-small]{width:70px;height:40px;border-radius:6px;}',
      '[data-sk-msg]{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary,#6b7280);}',
      '[data-sk-msg][data-bad]{color:#d93025;}',
      '[data-sk-msg][data-good]{color:#2e7d32;}',
      '[data-sk-status]{font-size:11px;line-height:16px;}',
      '[data-sk-status][data-kind="ok"]{color:#2e7d32;}',
      '[data-sk-status][data-kind="err"]{color:#d93025;}',
      '[data-sk-status][data-kind="busy"]{color:#9aa0a6;}',
      '[data-sk-disabled]{opacity:.45;pointer-events:none;}',
      '[data-sk-rule]{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.22));border-radius:10px;',
      '  padding:10px;display:flex;flex-direction:column;gap:8px;}',
      '[data-sk-rule][data-sk-on]{border-color:rgba(59,130,246,.45);}',
      '[data-sk-in]{padding:4px 8px;border-radius:6px;font-size:12px;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));',
      '  background:var(--dsw-alias-interactive-bg,rgba(128,128,128,.06));',
      '  color:var(--dsw-alias-label-primary,inherit);}',
      '[data-sk-in][data-sk-name]{width:120px;}',
      '[data-sk-in][data-sk-time]{width:100px;}',
      '[data-sk-in][data-sk-dt]{width:180px;}',
      '[data-sk-in][data-sk-path]{width:330px;font-family:ui-monospace,Consolas,monospace;}',
      '[data-sk-badge]{font-size:10px;padding:2px 6px;border-radius:999px;',
      '  background:rgba(59,130,246,.12);color:#3b82f6;}',
      '[data-sk-badge][data-sk-warn]{background:rgba(217,48,37,.12);color:#d93025;}',
      '[data-sk-now]{font-size:12px;color:var(--dsw-alias-label-secondary,#6b7280);}',
      '[data-sk-preview]{position:relative;height:150px;border-radius:10px;overflow:hidden;',
      '  border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));background:#fff;}',
      '[data-sk-preview-img]{position:absolute;inset:0;background-repeat:no-repeat;}',
      '[data-sk-preview-veil]{position:absolute;inset:0;}',
      '[data-sk-preview-tag]{position:absolute;left:8px;bottom:6px;font-size:11px;color:#374151;',
      '  background:rgba(255,255,255,.72);padding:1px 6px;border-radius:6px;}',
      '[data-sk-float]{position:fixed;right:18px;bottom:18px;z-index:2147483000;width:300px;',
      '  background:rgba(24,26,32,.92);color:#f3f4f6;border-radius:12px;padding:10px 12px;',
      '  box-shadow:0 10px 30px rgba(0,0,0,.35);font:12px/1.5 system-ui;display:none;}',
      '[data-sk-float-head]{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;}',
      '[data-sk-float-title]{font-size:12px;font-weight:600;}',
      '[data-sk-float-close]{background:transparent;border:0;color:#f3f4f6;font-size:16px;cursor:pointer;line-height:1;}',
      '[data-sk-float-row]{display:flex;align-items:center;gap:8px;margin:4px 0;}',
      '[data-sk-float-lab]{width:34px;flex:none;opacity:.8;}',
      '[data-sk-float-row] input[type=range]{flex:1;accent-color:#60a5fa;}',
      '[data-sk-float-val]{width:36px;text-align:right;font-variant-numeric:tabular-nums;opacity:.85;}',
      '[data-sk-float-foot]{margin-top:6px;font-size:10px;opacity:.55;}',
    ].join('\n')

    function PreviewBox(props) {
      const ent = props.ent || {}
      const url = props.url || ''
      const clarity = clamp(ent.clarity, 0, 100)
      const mid = 0.92 - 0.004 * clarity
      const top = Math.min(0.985, mid + 0.26)
      const bot = Math.min(0.985, mid + 0.12)
      const blur = clamp(ent.blur, 0, 12)
      const posX = clamp(ent.posX, 0, 100)
      const posY = clamp(ent.posY, 0, 100)
      return h('div', { 'data-sk-preview': '' },
        h('div', {
          'data-sk-preview-img': '',
          style: {
            backgroundImage: url ? ('url("' + url + '")') : WHITE_ART,
            backgroundSize: 'cover',
            backgroundPosition: posX + '% ' + posY + '%',
            filter: 'blur(' + blur + 'px)',
            transform: 'scale(1.04)',
          },
        }),
        h('div', {
          'data-sk-preview-veil': '',
          style: {
            backgroundImage: 'linear-gradient(180deg,' +
              'rgba(255,255,255,' + top.toFixed(3) + ') 0%,' +
              'rgba(255,255,255,' + Math.max(0, mid - 0.02).toFixed(3) + ') 18%,' +
              'rgba(255,255,255,' + mid.toFixed(3) + ') 55%,' +
              'rgba(255,255,255,' + bot.toFixed(3) + ') 100%)',
          },
        }),
        h('div', { 'data-sk-preview-tag': '' }, props.label || '实时预览'),
      )
    }

    function ToggleRow(props) {
      return h('div', { 'data-sk-row': '' },
        h('div', { 'data-sk-grow': '' },
          h('div', { 'data-sk-label': '' }, props.label),
          props.note ? h('div', { 'data-sk-note': '' }, props.note) : null),
        h('button', {
          'data-sk-sw': '',
          'data-on': props.on ? '' : undefined,
          onClick: function () { props.onChange(!props.on) },
          'aria-pressed': props.on ? 'true' : 'false',
        }, h('i')),
      )
    }

    function SliderRow(props) {
      return h('div', { 'data-sk-row': '' },
        h('div', { 'data-sk-grow': '' }, h('div', { 'data-sk-label': '' }, props.label)),
        h('input', {
          'data-sk-range': '',
          type: 'range',
          min: props.min, max: props.max, step: props.step,
          value: props.value,
          onChange: function (e) { props.onChange(Number(e.target.value)) },
        }),
        h('span', { 'data-sk-val': '' }, props.display),
      )
    }

    function PathBox(props) {
      const [v, setV] = React.useState(props.value || '')
      const [st, setSt] = React.useState({ kind: 'idle', text: '' })
      const last = React.useRef(props.value || '')
      const skip = React.useRef(false)

      React.useEffect(() => {
        setV(props.value || '')
        last.current = props.value || ''
      }, [props.value])

      const run = async (val) => {
        const p = String(val || '').trim()
        if (p === last.current) return
        last.current = p
        if (!p) {
          setSt({ kind: 'idle', text: '' })
          try { await props.onCommit('') } catch (e) { /* noop */ }
          return
        }
        setSt({ kind: 'busy', text: '检测中…' })
        try {
          const r = await props.onCommit(p)
          setSt(r && r.ok ? { kind: 'ok', text: '已应用' } : { kind: 'err', text: (r && r.message) || '读不到这张图' })
        } catch (e) {
          setSt({ kind: 'err', text: String((e && e.message) || e) })
        }
      }

      const guard = (fn) => { skip.current = true; if (fn) fn() }

      return h('div', { 'data-sk-row': '' },
        h('input', {
          'data-sk-in': '', 'data-sk-path': '',
          value: v,
          placeholder: '粘贴完整路径，回车生效（例：D:\\图片\\a.jpg）',
          onChange: (e) => setV(e.target.value),
          onKeyDown: (e) => { if (e.key === 'Enter') { e.preventDefault(); run(v) } },
          onBlur: () => { if (skip.current) { skip.current = false; return } run(v) },
        }),
        h('span', { 'data-sk-status': '', 'data-kind': st.kind }, st.text),
        props.onCopy
          ? h('button', { 'data-sk-btn': '', 'data-sk-mini': '', onMouseDown: () => guard(), onClick: props.onCopy }, '换成…')
          : null,
        props.onClear
          ? h('button', { 'data-sk-btn': '', 'data-sk-mini': '', onMouseDown: () => guard(), onClick: props.onClear }, '清除')
          : null,
      )
    }

    function Panel(props) {
      const [, force] = React.useReducer((x) => x + 1, 0)
      const [msg, setMsg] = React.useState('')
      const [bad, setBad] = React.useState(false)
      const [open, setOpen] = React.useState({})
      const [ghost, setGhost] = React.useState(false)
      const fileRef = React.useRef(null)
      const pending = React.useRef(null)
      const pageRef = React.useRef(null)
      const ghostEl = React.useRef(null)

      React.useEffect(() => subscribe(() => force()), [])

      // 调试用：把设置面板（或它最近的浮层祖先）调成半透明，方便边调边看背景
      React.useEffect(() => {
        const restore = () => {
          const el = ghostEl.current
          if (!el) return
          try {
            el.style.opacity = el.__skPrevOpacity || ''
            el.style.transition = el.__skPrevTransition || ''
          } catch (e) { /* noop */ }
          ghostEl.current = null
        }
        if (!ghost) { restore(); return }
        const node = pageRef.current
        let el = node
        let target = null
        let bestArea = 0
        for (let i = 0; el && i < 12; i++, el = el.parentElement) {
          const r = el.getBoundingClientRect ? el.getBoundingClientRect() : null
          if (!r) continue
          const area = r.width * r.height
          const big = r.width >= window.innerWidth * 0.55 && r.height >= window.innerHeight * 0.55
          if (big && area > bestArea) { target = el; bestArea = area }
        }
        if (!target && node) target = node.parentElement
        if (!target) return
        ghostEl.current = target
        target.__skPrevOpacity = target.style.opacity || ''
        target.__skPrevTransition = target.style.transition || ''
        target.style.transition = 'opacity .2s'
        target.style.opacity = '0.35'
        return restore
      }, [ghost])

      const cfg = STORE.cfg
      const rules = Array.isArray(cfg.rules) ? cfg.rules : []
      const now = new Date()
      const hit = activeRule(cfg, now)
      const nb = nextBoundary(cfg, now)
      const dftEntry = cfg.default || DEFAULTS.default
      const previewEntry = hit || dftEntry
      const previewSlot = hit ? ('rule:' + hit.id) : 'default'
      const previewUrl = hasSource(previewEntry.source) ? sourceUrl(previewEntry.source, previewSlot) : ''
      const say = (t, isBad) => { setMsg(t); setBad(Boolean(isBad)) }

      const persist = (next, label) => {
        STORE.cfg = next
        sync()
        emit()
        schedule()
        const p = saveCfg(next)
        if (label) p.then((ok) => say(label + (ok ? '：已保存' : '：保存失败'), !ok))
        return p
      }
      const patchCfg = (p, label) => persist(Object.assign({}, STORE.cfg, p), label)
      const patchRule = (id, p, label) => {
        const next = rules.map((r) => (r.id === id ? Object.assign({}, r, p) : r))
        return persist(Object.assign({}, STORE.cfg, { rules: next }), label)
      }
      const patchWhen = (id, p, label) => {
        const next = rules.map((r) => (r.id === id ? Object.assign({}, r, { when: Object.assign({}, r.when || {}, p) }) : r))
        return persist(Object.assign({}, STORE.cfg, { rules: next }), label)
      }

      async function commitPath(slot, p) {
        const src = { kind: 'path', path: String(p || '').trim() }
        let next
        if (slot === 'default') {
          next = Object.assign({}, STORE.cfg, { default: Object.assign({}, STORE.cfg.default, { source: src }) })
        } else {
          const id = slot.slice(5)
          next = Object.assign({}, STORE.cfg, { rules: rules.map((r) => (r.id === id ? Object.assign({}, r, { source: src }) : r)) })
        }
        STORE.cfg = next
        sync(); emit()
        const ok = await saveCfg(next)
        if (!ok) return { ok: false, message: '配置没保存上' }
        if (!src.path) return { ok: true, message: '' }
        try {
          const r = await fetch(API + '/photo?slot=' + encodeURIComponent(slot), { cache: 'no-store' })
          if (r.ok) return { ok: true, message: '已应用' }
          const j = await r.json().catch(() => ({}))
          return { ok: false, message: '读不到：' + (j.error || ('HTTP ' + r.status)) }
        } catch (e) {
          return { ok: false, message: '检测失败：' + e.message }
        }
      }

      const onFile = (file) => {
        if (!file) return
        const slot = pending.current || 'default'
        if (!/^image\//.test(file.type)) { say('这不是图片文件', true); return }
        say('正在处理图片…')
        const fr = new FileReader()
        fr.onerror = () => say('读不出这个文件', true)
        fr.onload = () => {
          const im = new Image()
          im.onerror = () => say('这张图解不开', true)
          im.onload = async () => {
            try {
              const max = 2048
              const scale = Math.min(1, max / Math.max(im.width, im.height))
              const w = Math.max(1, Math.round(im.width * scale))
              const hh = Math.max(1, Math.round(im.height * scale))
              const c = document.createElement('canvas')
              c.width = w
              c.height = hh
              c.getContext('2d').drawImage(im, 0, 0, w, hh)
              const dataUrl = c.toDataURL('image/jpeg', 0.86)
              const up = await postJson('/image', { dataUrl })
              const src = { kind: 'copy', name: up.name }
              let next
              if (slot === 'default') next = Object.assign({}, STORE.cfg, { default: Object.assign({}, STORE.cfg.default, { source: src }) })
              else {
                const id = slot.slice(5)
                next = Object.assign({}, STORE.cfg, { rules: rules.map((r) => (r.id === id ? Object.assign({}, r, { source: src }) : r)) })
              }
              STORE.cfg = next
              sync(); emit()
              await saveCfg(next)
              say('已复制并应用（' + w + '×' + hh + '）')
            } catch (e) {
              say('图片保存失败：' + e.message, true)
            }
          }
          im.src = fr.result
        }
        fr.readAsDataURL(file)
      }

      const pickFile = (slot) => { pending.current = slot; if (fileRef.current) fileRef.current.click() }

      const addRule = (type) => {
        if (rules.length >= LIMIT) { say('最多 ' + LIMIT + ' 条规则，先删一条', true); return }
        const today = new Date()
        const iso = (d) => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes())
        const week = new Date(today.getTime() + 7 * 86400000)
        const base = { clarity: cfg.default.clarity, blur: cfg.default.blur, posX: cfg.default.posX, posY: cfg.default.posY }
        const rule = Object.assign({ id: uid(), name: type === 'daily' ? '每日时段' : '一次性时段', enabled: true, source: { kind: 'path', path: '' }, when: type === 'daily' ? { type: 'daily', from: '22:00', to: '06:00' } : { type: 'absolute', from: iso(today), to: iso(week) } }, base)
        persist(Object.assign({}, STORE.cfg, { rules: rules.concat([rule]) }), '已添加规则')
      }

      const ruleRows = rules.map((r) => {
        const isDaily = (r.when || {}).type === 'daily'
        const exp = isExpired(r, now)
        const url = hasSource(r.source) ? sourceUrl(r.source, 'rule:' + r.id) : ''
        const shown = open[r.id]
        return h('div', { 'data-sk-rule': '', key: r.id, 'data-sk-on': r.enabled && !exp ? '' : undefined },
          h('div', { 'data-sk-row': '' },
            h('button', {
              'data-sk-sw': '', 'data-on': r.enabled ? '' : undefined,
              onClick: () => patchRule(r.id, { enabled: !r.enabled }, r.enabled ? '规则已停用' : '规则已启用'),
            }, h('i')),
            h('input', {
              'data-sk-in': '', 'data-sk-name': '', value: r.name || '', placeholder: '规则名',
              onChange: (e) => patchRule(r.id, { name: e.target.value }),
            }),
            h('span', { 'data-sk-badge': '', 'data-sk-warn': exp ? '' : undefined }, isDaily ? '每日' : (exp ? '已过期' : '一次性')),
            h('div', { 'data-sk-grow': '' }),
            h('button', {
              'data-sk-btn': '', 'data-sk-mini': '',
              onClick: () => setOpen(Object.assign({}, open, { [r.id]: !shown })),
            }, shown ? '收起观感' : '观感'),
            h('button', { 'data-sk-btn': '', 'data-sk-mini': '', onClick: () => { persist(Object.assign({}, STORE.cfg, { rules: rules.filter((x) => x.id !== r.id) }), '已删除规则') } }, '删除'),
          ),
          h('div', { 'data-sk-row': '' },
            h('span', { 'data-sk-note': '' }, '从'),
            h('input', {
              'data-sk-in': '', 'data-sk-time': isDaily ? '' : undefined,
              ...(isDaily ? {} : { 'data-sk-dt': '' }),
              type: isDaily ? 'time' : 'datetime-local',
              value: (r.when || {}).from || '',
              onChange: (e) => patchWhen(r.id, { from: e.target.value }),
            }),
            h('span', { 'data-sk-note': '' }, '到'),
            h('input', {
              'data-sk-in': '', 'data-sk-time': isDaily ? '' : undefined,
              ...(isDaily ? {} : { 'data-sk-dt': '' }),
              type: isDaily ? 'time' : 'datetime-local',
              value: (r.when || {}).to || '',
              onChange: (e) => patchWhen(r.id, { to: e.target.value }),
            }),
            isDaily ? h('span', { 'data-sk-note': '' }, '（结束早于开始 = 跨午夜）') : null,
          ),
          h('div', { 'data-sk-row': '' },
            url
              ? h('img', { 'data-sk-thumb': '', 'data-sk-small': '', src: url, alt: '' })
              : h('div', { 'data-sk-thumb': '', 'data-sk-small': '', style: { backgroundImage: WHITE_ART } }),
            h(PathBox, {
              value: (r.source || {}).path || '',
              onCommit: (v) => commitPath('rule:' + r.id, v),
              onCopy: () => pickFile('rule:' + r.id),
              onClear: () => patchRule(r.id, { source: { kind: 'path', path: '' } }, '已清除图片'),
            }),
          ),
          shown ? h('div', { 'data-sk-sec': '' },
            h(SliderRow, {
              label: '图片强度', min: 0, max: 100, step: 5, value: num(r.clarity, 70),
              display: num(r.clarity, 70) + '%',
              onChange: (v) => patchRule(r.id, { clarity: v }),
            }),
            h(SliderRow, {
              label: '模糊', min: 0, max: 8, step: 0.4, value: num(r.blur, 1.2),
              display: num(r.blur, 1.2).toFixed(1),
              onChange: (v) => patchRule(r.id, { blur: v }),
            }),
            h(SliderRow, {
              label: '水平位置', min: 0, max: 100, step: 1, value: num(r.posX, 50),
              display: num(r.posX, 50) + '%',
              onChange: (v) => patchRule(r.id, { posX: v }),
            }),
            h(SliderRow, {
              label: '垂直位置', min: 0, max: 100, step: 1, value: num(r.posY, 40),
              display: num(r.posY, 40) + '%',
              onChange: (v) => patchRule(r.id, { posY: v }),
            }),
          ) : null,
        )
      })

      const dft = cfg.default || DEFAULTS.default
      const dftUrl = hasSource(dft.source) ? sourceUrl(dft.source, 'default') : ''

      return h('div', { 'data-sk-page': '', ref: pageRef },
        h('div', { 'data-sk-sec': '' },
          h('div', { 'data-sk-h': '' }, '模式'),
          h('div', { 'data-sk-row': '' },
            h('button', {
              'data-sk-btn': '', 'data-sk-on': cfg.mode !== 'multi' ? '' : undefined,
              onClick: () => patchCfg({ mode: 'single' }, '已切换到单一背景模式'),
            }, '单一背景'),
            h('button', {
              'data-sk-btn': '', 'data-sk-on': cfg.mode === 'multi' ? '' : undefined,
              onClick: () => patchCfg({ mode: 'multi' }, '已切换到多背景模式'),
            }, '多背景 + 时段'),
            h('div', { 'data-sk-grow': '' }),
            h('span', { 'data-sk-note': '' }, cfg.mode === 'multi' ? '按规则自动切换' : '只有一张背景，不按时段变')),
        ),

        h(ToggleRow, {
          label: '启用背景',
          note: '只影响中间那一栏（工作区 / 首页）。',
          on: cfg.enabled,
          onChange: (v) => patchCfg({ enabled: v }, v ? '已启用' : '已关闭'),
        }),
        h(ToggleRow, {
          label: '深色主题下自动变暗',
          note: '深色皮肤时把白薄纱换成深色',
          on: cfg.darkFollow,
          onChange: (v) => patchCfg({ darkFollow: v }),
        }),

        h('div', { 'data-sk-row': '' },
          h('button', {
            'data-sk-btn': '', 'data-sk-on': ghost ? '' : undefined,
            onClick: () => setGhost(!ghost),
          }, ghost ? '取消半透明' : '调试：面板半透明'),
          h('button', {
            'data-sk-btn': '',
            onClick: () => { openFloat(); if (props && typeof props.close === 'function') props.close() },
          }, '悬浮调参（边看工作区边调）'),
          props && typeof props.close === 'function'
            ? h('button', {
                'data-sk-btn': '', 'data-sk-mini': '',
                onClick: () => { setGhost(false); props.close() },
              }, '关掉设置看效果')
            : null,
          h('div', { 'data-sk-grow': '' }),
          h('span', { 'data-sk-note': '' }, '半透明只影响设置面板本身，方便边调边看背景'),
        ),

        h('div', { 'data-sk-sec': '' },
          h('div', { 'data-sk-h': '' }, cfg.mode === 'multi' ? '默认背景（没有规则命中时用）' : '背景图'),
          h('div', { 'data-sk-row': '' },
            dftUrl
              ? h('img', { 'data-sk-thumb': '', src: dftUrl, alt: '' })
              : h('div', { 'data-sk-thumb': '', style: { backgroundImage: WHITE_ART } }),
            h(PathBox, {
              value: (dft.source || {}).path || '',
              onCommit: (v) => commitPath('default', v),
              onCopy: () => pickFile('default'),
              onClear: () => patchCfg({ default: Object.assign({}, dft, { source: { kind: 'path', path: '' } }) }, '已清除图片'),
            }),
          ),
          h(SliderRow, {
            label: '图片强度', note: '越大越清楚，字越吃力',
            min: 0, max: 100, step: 5, value: num(dft.clarity, 70),
            display: num(dft.clarity, 70) + '%',
            onChange: (v) => patchCfg({ default: Object.assign({}, dft, { clarity: v }) }),
          }),
          h(SliderRow, {
            label: '模糊', min: 0, max: 8, step: 0.4, value: num(dft.blur, 1.2),
            display: num(dft.blur, 1.2).toFixed(1),
            onChange: (v) => patchCfg({ default: Object.assign({}, dft, { blur: v }) }),
          }),
          h(SliderRow, {
            label: '水平位置', min: 0, max: 100, step: 1, value: num(dft.posX, 50),
            display: num(dft.posX, 50) + '%',
            onChange: (v) => patchCfg({ default: Object.assign({}, dft, { posX: v }) }),
          }),
          h(SliderRow, {
            label: '垂直位置', min: 0, max: 100, step: 1, value: num(dft.posY, 40),
            display: num(dft.posY, 40) + '%',
            onChange: (v) => patchCfg({ default: Object.assign({}, dft, { posY: v }) }),
          }),
          h('div', { 'data-sk-note': '' }, '默认直接引用原图，不复制；原图被移动/删除时会退回白底并提示。'),
        ),

        cfg.mode === 'multi'
          ? h('div', { 'data-sk-sec': '' },
              h('div', { 'data-sk-row': '' },
                h('div', { 'data-sk-h': '' }, '时段规则　' + rules.length + '/' + LIMIT),
                h('div', { 'data-sk-grow': '' }),
                h('button', { 'data-sk-btn': '', 'data-sk-mini': '', disabled: rules.length >= LIMIT, onClick: () => addRule('daily') }, '+ 每日时段'),
                h('button', { 'data-sk-btn': '', 'data-sk-mini': '', disabled: rules.length >= LIMIT, onClick: () => addRule('absolute') }, '+ 一次性时段'),
              ),
              h('div', { 'data-sk-now': '' },
                '现在：' + (hit ? (hit.name || '未命名规则') : '默认背景')
                + (hit ? '（' + num(hit.clarity, 70) + '% / 模糊 ' + num(hit.blur, 1.2).toFixed(1) + '）' : '')
                + (Number.isFinite(nb) ? '　｜　下次切换：' + fmtBoundary(nb, now) : '')),
              rules.length ? h('div', { 'data-sk-sec': '' }, ruleRows) : h('div', { 'data-sk-note': '' }, '还没有规则。'),
            )
          : null,

        h('input', {
          ref: fileRef, type: 'file', accept: 'image/*', style: { display: 'none' },
          onChange: function (e) {
            const f = e.target.files && e.target.files[0]
            onFile(f)
            e.target.value = ''
          },
        }),

        msg ? h('div', { 'data-sk-msg': '', 'data-bad': bad ? '' : undefined, 'data-good': !bad && msg ? '' : undefined }, msg) : null,
        h('div', { 'data-sk-note': '' },
          '配置存本机磁盘（' + (STORE.source === 'disk' ? '已从磁盘读取' : '已迁移到磁盘') + '），重启后仍在。'),
        STORE.error ? h('div', { 'data-sk-msg': '', 'data-bad': '' }, STORE.error) : null,
      )
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        skinStyle = document.createElement('style')
        skinStyle.id = 'dsh-skin-sakura:styles'
        document.head.appendChild(skinStyle)

        const uiStyle = document.createElement('style')
        uiStyle.setAttribute('data-plugin-css', 'dsh-skin-sakura')
        uiStyle.textContent = CSS
        document.head.appendChild(uiStyle)

        if (ctx && typeof ctx.effect === 'function') {
          ctx.effect(() => () => {
            skinStyle.remove()
            uiStyle.remove()
            if (tickTimer) clearTimeout(tickTimer)
            if (floatUI && floatUI.box && floatUI.box.parentElement) floatUI.box.remove()
          }, 'dsh-skin-sakura: 背景样式')
        }

        subscribe(sync)
        applySkin(STORE.cfg, STORE.cfg.default, '')
        boot().catch(() => { /* 宿主不可用时保持默认 */ })
        schedule()

        document.addEventListener('visibilitychange', () => {
          if (!document.hidden) { sync(); schedule() }
        })

        const slots = (typeof ctx.get === 'function' ? ctx.get('slots') : undefined) || ctx.slots
        if (!slots) return
        try {
          slots.inject('settings.section', () => slots.register(
            { name: 'settings.section', id: 'skin-sakura', order: 40, label: '背景皮肤' },
            (props) => h(Panel, props),
          ))
        } catch (e) {
          console.warn('[dsh-skin-sakura] 设置页注册失败：', e)
        }
      },
    }
  },
})
