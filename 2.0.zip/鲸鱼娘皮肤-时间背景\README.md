# dsh-skin-sakura

给 DeepSeek Harness 的 Web GUI 换背景：**只作用于中间那一栏**（工作区对话 + 首页），左侧栏、窗口标题栏、右侧面板都保持原样。

自带默认是**纯白背景**（与 DSH 原生一致，装了什么都不会变）；想换成自己的图，在设置里传一张就行（只存在本机，不会上传）。

## 安装

```bash
dsh plugin --profile desktop add dsh-skin-sakura
```

本地目录 / 安装包：

```bash
dsh plugin --profile desktop add "link:<本目录绝对路径>"
dsh plugin --profile desktop add "file:<...>.tgz"
```

装完**重启 DSH**。`dsh plugin add` 会自动把插件登记进
`~/.dsh/profiles/desktop/package.json` 的 `dsh.profile.bundles`。

卸载：

```bash
dsh plugin --profile desktop remove dsh-skin-sakura
```

## 设置

**设置 → 插件 → 背景皮肤**

| 项 | 说明 |
| --- | --- |
| 启用背景 | 总开关，关掉立刻回到 DSH 原样 |
| 图片强度 | 0–100%，越大图越清楚、字越吃力（默认 70%） |
| 模糊 | 0–8px，0 = 完全不糊（默认 1.2px） |
| 深色主题下自动变暗 | 深色皮肤时把白薄纱换成深色 |
| 水平 / 垂直位置 | 取景（默认 50% / 40%） |
| 选择图片… | 本地上传，自动缩到 2048px 内并转 JPEG |
| 恢复默认 | 回到默认白色（等于没换） |

配置和图片都存在本机 `localStorage`（`dsh-skin-sakura:v1` / `dsh-skin-sakura:image`），不联网、不上传、换设备不同步。

## 它做了什么

一个纯前端插件：往 `<head>` 里插两段 `<style>`（一段皮肤、一段设置页），外加一个设置页。

- 把中栏（`div[class*="_centerCol"]`）变成定位上下文，用 `::before` 铺一层
  `blur()` 背景 + 白色薄纱（保证文字可读）；
- 把中栏里原本的实色底（会话头、对话容器、滚动区、输入区、首页 hero）设成透明，露出背景；
- 深色主题换深色薄纱（`body[data-ds-dark-theme]`）。

不改宿主代码、不改任何文件、不联网；卸载即恢复原样。

## 开发

源码就是这个 `client.js`（没有构建步骤，改完重启 DSH 即生效）。
`index.js` 是宿主侧空壳，`cordis.patch.yml` 负责把插件挂进 bundle。

- 改默认观感：`client.js` 里的 `DEFAULTS`
- 换内置背景：`client.js` 里的 `WHITE_ART`（默认是纯白，也可以换成自己的渐变/颜色）

## License

MIT
